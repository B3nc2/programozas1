#include <stdio.h>
#define SIZE 100
void dekodolo(string szamok, string betuk, char cel[]){
    
}
int main(){
    string szamok = "25635146017";
    string betuk = "ZAPGMROS";
    char cel[SIZE];
    dekodolo(szamok,betuk,cel);


return 0;

}
